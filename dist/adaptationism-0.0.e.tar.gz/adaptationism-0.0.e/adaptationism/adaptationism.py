def helloworld(something):
	print(something)
