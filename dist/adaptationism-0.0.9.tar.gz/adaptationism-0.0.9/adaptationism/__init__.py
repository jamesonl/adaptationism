from .adaptationism import compute_usage, transition_table, gram_stats
