from .adaptationism import transition_table
